package com.problem3;
import java.util.Map;
import java.util.TreeMap;
public class Test {
	
	public static void main(String[] args) {
	Date d1 = new Date (9,2,2002);
	Date d2 = new Date (3,13,2003);
	Date d3 = new Date (10,23,2018);
	Date d4 = new Date (8,20,2020);
	
	TreeMap<Date, String> syllabus = new TreeMap();
	syllabus.put(d1, "Java");
	syllabus.put(d2, "Phyton");
	syllabus.put(d3, "JavaScript");
	syllabus.put(d4, "C++");

for(Map.Entry<Date, String> lesson : syllabus.entrySet()) {
	if(lesson.getKey().month == 9 && lesson.getKey().year == 2002) {
		System.out.println(lesson.getValue());
	}else {
		System.out.println(lesson.getValue() + " does not fall on September 2002.");
	}
}
	}
}


