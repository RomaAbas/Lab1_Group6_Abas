package com.problem2;

import java.util.Map;
import java.util.TreeMap;

public class Test {

	public static void main(String[] args) {
		
		Date d1 = new Date (9,2,2002);
		Date d2 = new Date (3,13,1994);
		Date d3 = new Date (10,23,2018);
		Date d4 = new Date (8,20,2020);
		
		//Problem 2
		
		if(d1.compareTo(d2) == 1) {
			System.out.println(d1 + " is more recent than " + d2);
		}else if (d1.compareTo(d2) == -1) {
			System.out.println(d1 + " is late than " + d2);
		}else {
			System.out.println(d1 + " and " + d2 + " are the same dates.");
		}
}
}